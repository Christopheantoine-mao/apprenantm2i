// Classe de base (classe parent)
public class Animal {
    public void manger() {
        System.out.println("L'animal mange.");
    }
}